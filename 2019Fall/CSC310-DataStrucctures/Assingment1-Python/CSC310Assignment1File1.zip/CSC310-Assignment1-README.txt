JOHN BOOKER
CSCS310
README FOR TIC TAC TOE ASSIGNMENT 1

To play the game, one must start the code. The board will be printed out as an array. The numbers on the top and left sides of the area are a key to designate
spots inside the tic tac toe board. A user will put in a string of numbers, designating the row first, then the collumn they want to place their symbol inside.
There is no need to type anything but the numbers of the row and then collumn that the user wants.

Examples of placement designation:
11
31
21
33

If an invalid or filled in spot is typed in, the board will appear again and ask for another input, saying the previous one was invalid.
