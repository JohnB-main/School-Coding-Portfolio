from map_base import MapBase

class UnsortedTableMap(MapBase):
    """Map implementation using an unordered list."""

    def __init__(self):
        """Create an empty map."""
        self._table = []  # list of _Item's

    def __getitem__(self, k):
        """Return value associated with key k (raise KeyError if not found)."""
        for item in self._table:
            if k == item._key:
                return item._value
        raise KeyError('Key Error: ' + repr(k))

    def __setitem__(self, k, v):
        """Assign value v to key k, overwriting existing value if present."""
        for item in self._table:
            if k == item._key:  # Found a match:
                item._value = v  # reassign value
                return  # and quit
        # did not find match for key
        self._table.append(self._Item(k, v))

    def __delitem__(self, k):
        """Remove item associated with key k (raise KeyError if not found)."""
        for j in range(len(self._table)):
            if k == self._table[j]._key:  # Found a match:
                self._table.pop(j)  # remove item
                return  # and quit
        raise KeyError('Key Error: ' + repr(k))

    def __len__(self):
        """Return number of items in the map."""
        return len(self._table)

    def __iter__(self):
        """Generate iteration of the map's keys."""
        for item in self._table:
            yield item._key  # yield the KEY


if __name__ == '__main__':
    M = UnsortedTableMap()  # Create Unsorted TableMap[]

    # set three key-value pairs to TableMap
    M.__setitem__('a', 1)
    M.__setitem__('c', 2)
    M.__setitem__('d', 3)

    print('Total length(M): ', len(M))
    print('Value with the key a', M.__getitem__('a'))

    #M.__delitem__('c')  # remove the pair with the key c
    print('Total length(M): ', len(M))
    print (M.__getitem__('c')) #call a deleted key c

    M.__setitem__('a', 4)  # override a value to the same key
    print(M.__getitem__('a'))  # return a value with the key a

    M.__setitem__('b', 5)  # add a new key-value pair
    print(M.__getitem__('b'))  # return a value with the key b

    print('** Show the unsorted keys in TableMap **')
    for i in M:  # create an iterator M for keys
        print(i)  # print all the keys on M
