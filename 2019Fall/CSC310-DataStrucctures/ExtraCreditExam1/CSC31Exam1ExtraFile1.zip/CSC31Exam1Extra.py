# We do not need 3 stacks to keep track of the disks, we only need to change the names around
# recursive function
def hanoi(n, origin, extra, target):
    # size of one
    if n == 1:
        print("Move disk 1 from peg", origin, "to peg", target)
        return
    # recursive call and change places
    hanoi(n - 1, origin, target, extra)
    print("Move disk", n, "from peg", origin, "to peg", target)
    # recursive call and change places
    hanoi(n - 1, extra, origin, target)


# n is the amount of disks
n = (int(input("Please input a positive, integer number: ")))
hanoi(n, 'A', 'B', 'C')



