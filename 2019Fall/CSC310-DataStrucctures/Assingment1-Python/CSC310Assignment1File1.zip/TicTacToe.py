# method to print the tic tac toe board
def printB():
    #variables
    global player
    global moves
    global spots
    global won
    global board
    #print the board
    for i in range(4):
        for j in range(4):
            print(board[i][j], end=' ')
        print()#spacing
    print()#spacing


# method for checking to see if there is a winner
def iswon():
    global player
    global moves
    global spots
    global won
    global board
    # possible winning combinations
    if ((board[1][1] == board[1][2] == board[1][3] == player) | (
            board[1][1] == board[2][1] == board[3][1] == player) | (
            board[1][1] == board[2][
        2] == board[3][3] == player) | (board[3][3] == board[3][2] == board[3][1] == player) | (
            board[3][3] == board[2][3] == board[1][3] == player) |
            (board[3][1] == board[2][2] == board[1][3] == player) | (
                    board[2][1] == board[2][2] == board[2][3] == player) | (board[1][2] ==
                                                                            board[2][2] ==
                                                                            board[3][2] == player)):
        print('THE WINNER IS PLAYER ', player, '!')  # Print the winner and change the boolean
        won = True
        return
    else:
        if moves >= 9:  # a tie game
            won = True
            print('THE GAME IS A TIE')
            return
    return#not needed, but paranoid


def turn():
    global player
    global moves
    global spots
    global won
    global board
    # get input from user
    spot = input('Pick a position [row][col] (11,12,22): ')
    # check to see if the spot is available
    if spots.__contains__(spot) == False:
        # no: print invalid and return
        print('Invalid Location')
        return
    else:
        # valid location, remove it from the list
        spots.remove(spot)
        # check to see which spot was given and fill it with the current player symbol
        if spot == '11':
            board[1][1] = player

        if spot == '12':
            board[1][2] = player

        if spot == '13':
            board[1][3] = player

        if spot == '21':
            board[2][1] = player

        if spot == '22':
            board[2][2] = player

        if spot == '23':
            board[2][3] = player

        if spot == '31':
            board[3][1] = player

        if spot == '32':
            board[3][2] = player

        if spot == '33':
            board[3][3] = player

        # add to the amount of moves made
        moves += 1

        # check to see if the game is won
        iswon()

        # change players of the game
        if player == 'X':
            player = 'O'
        else:
            if player == 'O':
                player = 'X'


# tic tac toe board
board = [[' ', '1', '2', '3'], ['1', ' ', ' ', ' '], ['2', ' ', ' ', ' '], ['3', ' ', ' ', ' ']]
# list of possible spots left to use
spots = ['11', '12', '13', '21', '22', '23', '31', '32', '33']
# counter for the moves to check if there is a tie game
moves = 0
# player variable for changing players
player = 'X'
# boolean as a win condition/game over
won = False

# print the board to start the game
printB()

# while loop to continue taking turns
while won == False:
    turn()
    printB() # show progression of board
